<?php

 include("connection.php");
  if(isset($_POST["submit"]))
  {
           $name=$_POST["name"];
           $email=$_POST["email"];
           $password=$_POST["password"];
           $mobile=$_POST["mobile"];
           $country=$_POST["country"];
           $state=$_POST["state"];
           $city=$_POST["city"];
           $area=$_POST["area"];

   $query="INSERT INTO user(name,email,password,mobile,country,state,city,area)VALUES('$name','$email','$password','$mobile',$country,$state,$city,'$area')";
   // mysqli_query($conn,$query);
    // $data=myslqi_fetch_array($res)

          

    // $rows=mysqli_affected_rows($res);

    // echo  $rows;
    // die();

    if(mysqli_query($conn,$query)>0)
    {
    	echo "Data inserted Succesfully";
    }
    else
    {
    	echo "Try again";
    }





  }

 ?>



<html>
  <head>

  	<title>Form task</title>
  	  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  </head>
<body>


<div class="container">

	 <h4>Registration Form</h4>
	 <hr/>

    <form  method="post">
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="name" class="form-control" placeholder="Enter Name" id="name" name="name">
  </div>
  <div class="form-group">
    <label for="Email">Email:</label>
    <input type="email" class="form-control" placeholder="Enter Email" id="email" name="email">
  </div>

  <div class="form-group">
    <label for="passwod">Passwod:</label>
    <input type="passwod" class="form-control" placeholder="Enter passwod" id="passwod" name="password">
  </div>

  <div class="form-group">
    <label for="mobile">Mobile No:</label>
    <input type="text" class="form-control" placeholder="Enter mobile no" id="mobile" name="mobile">
  </div>

  <div class="form-group">
	 <label for="country">Country</label>
	   <select class="form-control" id="country" name="country">
		 <option value="-1">Select Country</option>
			   <?php
                   $sql="SELECT * FROM country ";
                   $result=mysqli_query($conn,$sql);
			     while($country=mysqli_fetch_array($result)){
				 ?>
				 <option value="<?php echo $country['id']?>"><?php echo $country['name']?></option>
				 <?php
				  }
				 ?>
			</select>
	 </div>

	 <div class="form-group">
	    <label for="state">State</label>
		  <select class="form-control" id="state" name="state">
			<option value="0">Select State</option>
		  </select>
	 </div>


	 <div class="form-group">
						<label for="city">City</label>
						<select class="form-control" id="city" name="city">
							<option >Select City</option>
						</select>
					</div>

	 <div class="form-group">
	 	     <label>Area:</label>
	 	     <input type="text"  class="form-control" name="area" id="area">
	 
	 </div>				


  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>

   


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>

  $(document).ready(function(){


      $('#country').on("change",function(){
                
             var countryId= $(this).val();

             //alert(countryId);

            $.ajax({
                   
                 type:"POST",
                 url:"get-state.php",
                 data:{id:countryId},
                 success:function(data){

                    $('#state').html(data);


                 }

            });


      });




       $('#state').on("change",function(){
                
             var stateId= $(this).val();

             //alert(stateId);

            $.ajax({
                   
                 type:"POST",
                 url:"get-city.php",
                 data:{id:stateId},
                 success:function(data){

                    $('#city').html(data);


                 }

            });


      });

  });


</script>


</body>



</html>