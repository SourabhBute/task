<?php

$conn=mysqli_connect("localhost","root", "" ,"dropdown") or die("connection failed");

 ?>