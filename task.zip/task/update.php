<?php

 include("connection.php");
  if(isset($_POST["Update"]))
  {
           $name=$_POST["name"];
           $email=$_POST["email"];
           $password=$_POST["password"];
           $mobile=$_POST["mobile"];
           $country=$_POST["country"];
           $state=$_POST["state"];
           $city=$_POST["city"];
           $area=$_POST["area"];

            // echo "<pre>";
            // print_r($_POST);
            //  die("data check");

  echo $query="UPDATE user SET name='$name',email='$email',password='$password',mobile='$mobile',country=$country,state=$state,city=$city,area='$area' WHERE id=1";

  //die("data check");
    mysqli_query($conn,$query);
    // $data=myslqi_fetch_array($res)    
    // $rows=mysqli_affected_rows($res);
    // echo  $rows;
    // die();

    if(mysqli_query($conn,$query)>0)
    {
    	echo "Data updated Succesfully";
    }
    else
    {
    	echo " Data not updated try again";
    }
  }

 ?>
<html>
  <head>
  	<title>Update Form </title>
  	  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  </head>
<body>
    <?php 
          $sql1="SELECT * FROM user WHERE id=1";
            $res=mysqli_query($conn,$sql1);
            $row=mysqli_num_rows($res);
            $data=mysqli_fetch_array($res);

            //  echo "<pre>";

            // print_r($data);

            // echo  $data=$data["name"];
            //       die("check row");

?>


<div class="container">

	 <h4>Update Form</h4>
	 <hr/>

    <form  method="post">
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="name" class="form-control" placeholder="Enter Name" id="name" name="name" value="<?php
    echo $data["name"] ?>">
  </div>
  <div class="form-group">
    <label for="Email">Email:</label>
    <input type="email" class="form-control" placeholder="Enter Email" id="email" name="email"
     value="<?php echo $data["email"];?>">
  </div>

  <div class="form-group">
    <label for="passwod">Passwod:</label>
    <input type="passwod" class="form-control" placeholder="Enter passwod" id="passwod" name="password"
      value="<?php echo $data["password"];?>">
  </div>

  <div class="form-group">
    <label for="mobile">Mobile No:</label>
    <input type="text" class="form-control" placeholder="Enter mobile no" id="mobile" name="mobile"
     value="<?php echo $data["mobile"];?>">
  </div>

  <div class="form-group">
	 <label for="country">Country</label>
	   <select class="form-control" id="country" class="country" name="country">
		 <option value="-1">Select Country</option>
			   <?php
                   $sql="SELECT * FROM country ";
                   $result=mysqli_query($conn,$sql);
                   // $country=mysqli_fetch_array($result);
                   //  echo "<pre>";
                   //  print_r($country);
                   //  die("this is for country");
			     while($country=mysqli_fetch_array($result)){
				 ?>
				 <option  value="<?php echo $country['id']?>" <?php if($country['id']==$data['country']) echo 'selected="selected"'; ?> ><?php echo $country['name']?></option>
				 <?php
				  }
				 ?>
			</select>
	 </div>

   	 <div class="form-group">
	    <label for="state">State</label>
		  <select class="form-control" id="state" name="state">
			<option value="-2">Select State</option>

       <?php 
            $chkCountry=$data["country"];

            if($chkCountry==$data["country"])
            {
            $sql1="SELECT * FROM state WHERE country_id=".$data["country"]." ORDER BY name";
            $result1=mysqli_query($conn,$sql1);
            while($state=mysqli_fetch_array($result1)){
        ?>
      <option value="<?php echo $state['id'];?>" <?php if($state['id']==$data['state']) echo 'selected="selected"'; ?>><?php echo $state['name']?></option>
          <?php
        }
      }
        ?>
		  </select>
	 </div>
	 <div class="form-group">
						<label for="city">City</label>
						<select class="form-control" id="city" name="city">
							<option >Select City</option>
               <?php
                   $chkState=$data["state"];
                   if($chkState==$data["state"])
                     {     
                     $sql2="SELECT * FROM city WHERE state_id=".$data["state"]." ORDER BY name";
                      $result2=mysqli_query($conn,$sql2);
                      while($city=mysqli_fetch_array($result2)){
                ?>                              
               <option value="<?php echo $city['id'];?>" <?php if($city['id']==$data['city']) echo 'selected="selected"'; ?>><?php echo $city['name']?></option>
              <?php
                          }            
                      }
               ?>
						</select>					
    </div>
	 <div class="form-group">
	 	     <label>Area:</label>
	 	     <input type="text"  class="form-control" name="area" id="area" value="<?php
    echo $data["area"]; ?>">	 
	 </div>				
  <button type="submit" class="btn btn-primary" name="Update">Update</button>
</form>
 
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>



  $(document).ready(function(){  
      var countryId= $('#country').val();
      getState(countryId);
      $('#country').on('change',function(){  
            var countryId= $('#country').val();
            $.ajax({                   
                 type:"POST",
                 url:"get-state.php",
                 data:{id:countryId},
                 success:function(data){
                    $('#state').html(data);
                 }
            });
      });
      
      $('#state').on("change",function(){                
            var stateId= $(this).val();
            $.ajax({                   
                 type:"POST",
                 url:"get-city.php",
                 data:{id:stateId},
                 success:function(data){
                    $('#city').html(data);
                 }
            });
      });
  });

  function getState(countryId){

       alert(countryId);





  }
</script>
</body>
</html>