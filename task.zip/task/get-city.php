<?php 
   include("connection.php");

     if(isset($_POST["id"]))
      {   
     	  $id= $_POST["id"];

        $sql="SELECT * FROM city WHERE state_id='$id' ORDER BY name";
         $res=mysqli_query($conn,$sql);

         // $row=mysqli_fetch_array($res);

          // echo "<pre>";

         //  print_r($row);

         $output="";
             
       $output.="
            <option value='0'>Select City</option>
            ";

           while ($row=mysqli_fetch_array($res)) {
                 $id=$row["id"];
                 $state=$row["name"];

              $output.="<option value=".$id.">".$state."</option>";
           }


           

            echo $output;



   }








?>